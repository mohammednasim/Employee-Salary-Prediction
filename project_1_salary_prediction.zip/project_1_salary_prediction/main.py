from flask import Flask, render_template, request
import joblib

app = Flask(__name__)
model = joblib.load('model.pkl')  # Load your trained machine learning model


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        experience = float(request.form['experience'])
        test_score = float(request.form['test_score'])
        interview_score = float(request.form['interview_score'])

        # Make prediction using the loaded model
        predicted_salary = model.predict([[experience, test_score, interview_score]])[0]

        return render_template('index.html', prediction_text="Predicted Salary: ${:,.2f}".format(predicted_salary))

    return render_template('index.html')


if __name__ == '__main__':
    app.run(debug=True)