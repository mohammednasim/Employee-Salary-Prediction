import pandas as pd
from sklearn.linear_model import LinearRegression
import joblib

# Load the dataset from a CSV file
data = pd.read_csv('hiring.csv')

required_columns = ['experience', 'test_score', 'interview_score', 'salary']

# Check if all required columns are in the dataset
if all(col in data.columns for col in required_columns):
    # Prepare the data for training
    X = data[['experience', 'test_score', 'interview_score']]
    y = data['salary']

    # Create and train the model
    model = LinearRegression()
    model.fit(X, y)

    # Save the trained model to a file
    joblib.dump(model, 'model.pkl')
else:
    missing_columns = [col for col in required_columns if col not in data.columns]
    print(f"Error: Columns - {', '.join(missing_columns)} - not found in the dataset.")
